<?php
/**
 * Silence is golden
 *
 * @package  Kemet Addons
 */
