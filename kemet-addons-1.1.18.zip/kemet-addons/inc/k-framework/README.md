# K Framework

K Framework is a lightweight WordPress options framework developed to be used for K WordPress Theme and addon plugins.

## Available Fileds

- Background
- Button Set
- Checkbox
- Color
- Fieldset
- Group
- Icon
- Image Select
- Media
- Number
- Select
- Group
- Spacing
- Switcher
- Text
- Textarea
